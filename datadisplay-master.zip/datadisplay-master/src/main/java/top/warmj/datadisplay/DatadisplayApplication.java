package top.warmj.datadisplay;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DatadisplayApplication {

	public static void main(String[] args) {
		SpringApplication.run(DatadisplayApplication.class, args);
	}
}
